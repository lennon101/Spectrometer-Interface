import urllib2 

urllib2.urlopen("http://192.168.42.1/cgi-bin/getTwoSpectrum.php");