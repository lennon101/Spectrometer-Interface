'''
Print Mavlink msgs the 3DR Solo by Dane Lennon @ James Cook University 
DTG:  11-08-2016

A script for the 3DR Solo that prints all the mavlink msgs

There are listeners implemented that get the relevant mavlink msg and print the data

References: 
mavlink messages - https://github.com/mavlink/mavlink/blob/master/message_definitions/v1.0/common.xml
Creating a mavlink message listener - http://python.dronekit.io/guide/mavlink_messages.html
'''

from dronekit import connect
from time import sleep 

import sys

# Connect to UDP endpoint (and wait for default attributes to accumulate)
target = sys.argv[1] if len(sys.argv) >= 2 else 'udpin:0.0.0.0:14550'
print 'Connecting to ' + target + '...'
vehicle = connect(target, wait_ready=True)


#Create a message listener for all messages
#register a callback for all messages by setting the message name as the wildcard string ('*')
@vehicle.on_message('*')
def listener(self, name, message):
	print 'mavlink msg: %s' % message

while True:
	sleep(1);